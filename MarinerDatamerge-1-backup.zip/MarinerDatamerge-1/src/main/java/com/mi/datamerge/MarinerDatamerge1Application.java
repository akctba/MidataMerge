package com.mi.datamerge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarinerDatamerge1Application {

	public static void main(String[] args) {
		SpringApplication.run(MarinerDatamerge1Application.class, args);
	}

}
