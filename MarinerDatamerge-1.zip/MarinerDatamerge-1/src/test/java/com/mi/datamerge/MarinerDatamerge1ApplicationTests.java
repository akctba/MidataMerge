package com.mi.datamerge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarinerDatamerge1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
